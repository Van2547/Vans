function toggleSubjects(subjectsId) {
    var subjectsDiv = document.getElementById(subjectsId);
    if (subjectsDiv.style.display === 'none' || subjectsDiv.style.display === '') {
        subjectsDiv.style.display = 'block';
    } else {
        subjectsDiv.style.display = 'none';
    }
}
